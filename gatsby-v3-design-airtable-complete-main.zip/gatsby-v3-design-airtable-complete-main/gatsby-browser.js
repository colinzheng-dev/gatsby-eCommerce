import { wrapRootElement as wrap } from "./root-wrapper"

export const wrapRootElement = wrap
